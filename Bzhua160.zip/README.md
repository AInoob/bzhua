# bzhua
A Chrome Extension that fetches data from bilibili.com
